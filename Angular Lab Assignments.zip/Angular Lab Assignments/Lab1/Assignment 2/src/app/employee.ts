export class Employee {
    id:number;
    name:string;
    salary:number;
    department:string;

    constructor(id:number, name:string, salary:number, department:string)
    {
        this.id = id;
        this.name = name;
        this.salary = salary;
        this.department = department;
    }
}
