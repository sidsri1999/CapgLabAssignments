export class BasicPhone {
}
