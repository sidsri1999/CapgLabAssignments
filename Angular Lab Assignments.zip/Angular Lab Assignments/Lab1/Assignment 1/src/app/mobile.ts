export class Mobile {
    mobileId:number;
    mobileName:string;
    mobileCost:number;

    printMobileDetail(){
        console.log("Mobile Id"+this.mobileId+" Mobile Name "+this.mobileName+" Mobile Cost "+this.mobileCost+" Mobile Type ");
    }
}
