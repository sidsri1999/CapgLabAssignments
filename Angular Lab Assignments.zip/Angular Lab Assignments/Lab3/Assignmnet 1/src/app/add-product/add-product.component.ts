import { Component, OnInit } from '@angular/core';
import { Product } from '../product';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  product:Product = new Product(0,"",0,"","",null);
  
  constructor() { }

  ngOnInit(): void {
  }

  check()
  {
    console.log(this.product.id);
    console.log(this.product.name);
    console.log(this.product.cost);
    console.log(this.product.online);
    console.log(this.product.availablestores);
    
  }

}
