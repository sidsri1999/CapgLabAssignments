import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {

  employeeModel:Employee = new Employee(0,'',0,'');
  service:EmployeeService;

  constructor(service:EmployeeService) { 
    this.service = service;
  }

  ngOnInit(): void {
  }

  addEmployee()
  {
    this.service.addEmployee(this.employeeModel);
    this.employeeModel = new Employee(0,'',0,'');
  }

  msg : string;

  getMessage(message:string)
  {
    this.msg = message;
  }

}
