import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-view-employee',
  templateUrl: './view-employee.component.html',
  styleUrls: ['./view-employee.component.css']
})
export class ViewEmployeeComponent implements OnInit {

  employees:Array<Employee> = [];
  service:EmployeeService;

  updateemployee:Employee;

  msg : string;
  @Output() sendmsg = new EventEmitter<string>();
  

  getMessage(message:string)
  {
    this.msg = message;
    this.sendmsg.emit(message);
  }

  constructor(service:EmployeeService) {
    this.service = service;
   }

  ngOnInit(): void {
    this.employees = this.service.getAllEmployees();
    this.updateemployee = new Employee(0,"",0,"");
  }

  doUpdate(emp:Employee)
  {
    this.updateemployee = emp;
  }

  doDelete(emp:Employee)
  {
    let index = this.employees.indexOf(emp);
    for(let i=0;i<this.employees.length;i++)
    {
      if(i === index)
        this.employees.splice(i,1);
    }
    this.sendmsg.emit("DATA DELETED");
  }

}
